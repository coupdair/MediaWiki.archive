#!/bin/bash

version=mediawiki-1.9.3
data=data
wiki=Project
w=p

./mediawiki.save.sh $version $data $wiki $w

