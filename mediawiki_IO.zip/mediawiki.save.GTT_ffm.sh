#!/bin/bash

version=mediawiki-1.9.3
data=data
wiki=GTT_ffm
w=gttffm

./mediawiki.save.sh $version $data $wiki $w

