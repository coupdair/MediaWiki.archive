#!/bin/bash

version=$1
data=$2
wiki=$3
w=$4

wikiuser=wikiuser_$w
wikidb=wikidb_$w
fiSQL=Wiki$wiki.sql
fi=Wiki$wiki.tgz

#Untar mediawiki binary, data and database(.sql)
tar xvfz $fi

#Restore database
mysql --default-character-set=latin1 \
      -h localhost -D $wikidb \
      -u $wikiuser -phw4db < $fiSQL
rm $fiSQL

#On server only: add the following line into httpd.conf
##Include conf/conf.d/mediawiki_HardWare.conf

#restart apache
/etc/init.d/httpd restart

