#!/bin/bash

version=mediawiki-1.9.3
data=data
wiki=Biblio
w=b

./mediawiki.save.sh $version $data $wiki $w

