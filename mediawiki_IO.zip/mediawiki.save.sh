#!/bin/bash

version=$1
data=$2
wiki=$3
w=$4

wikiuser=wikiuser_$w
wikidb=wikidb_$w
foSQL=Wiki$wiki.sql
fo=Wiki$wiki.tgz

mysqldump -u $wikiuser -p --default-character-set=latin1 -B $wikidb > $foSQL
#save mediawiki, data and database
tar cvfz $fo \
    $foSQL \
    /home/chroot/httpd/usr/local/apache2/conf/conf.d/mediawiki_$wiki.conf \
    /home/chroot/httpd/www/mediawiki/$wiki.$version/ \
    /home/chroot/httpd/www/mediawiki/$wiki.$data/ \
    /var/www/html/$wiki  \
    /var/www/html/$wiki.$data
rm $foSQL

