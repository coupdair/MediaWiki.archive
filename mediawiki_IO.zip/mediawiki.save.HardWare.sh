#!/bin/bash

version=mediawiki-1.9.3
data=data
wiki=HardWare
w=hw

./mediawiki.save.sh $version $data $wiki $w

