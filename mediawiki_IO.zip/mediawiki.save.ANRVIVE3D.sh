#!/bin/bash

version=mediawiki-1.9.3
data=data
wiki=ANRVIVE3D
w=vive3d

./mediawiki.save.sh $version $data $wiki $w

